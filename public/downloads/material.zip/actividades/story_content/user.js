function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5xMjEll5psG":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

